# R: Historical ENSO region sea-surface temperatures

**Question:** How did recorded sea-surface temperatures change over the available historical years?

Run `Rscript analysis.R` (base R only). Outputs a trend figure, annual means and a linear regression plus Welch two-sample test comparing years before 1980 with 1980 onward.

**Source:** [statsmodels El Niño dataset](https://www.statsmodels.org/stable/datasets/generated/elnino.html), monthly sea-surface temperatures, 1950–2010. The pre/post-1980 comparison is exploratory, not evidence of a causal regime shift. Serial correlation may invalidate naive standard errors. This is **not** a socioeconomic pollution-exposure dataset.

# Python: Atmospheric CO₂ trend analysis

**Question:** How has measured atmospheric CO₂ at Mauna Loa changed over the available historical sample?

Run `python analysis.py` to regenerate `annual_summary.csv` and `co2_trend.png`. Uses pandas for aggregation, NumPy for a descriptive least-squares trend, and Matplotlib for visualization.

**Source:** Mauna Loa atmospheric CO₂ series, Scripps/Keeling, distributed in [statsmodels CO₂ dataset](https://www.statsmodels.org/stable/datasets/generated/co2.html). The trend is descriptive, not a causal estimate or emissions inventory. Missing observations are dropped before annual averaging; partial years may remain.

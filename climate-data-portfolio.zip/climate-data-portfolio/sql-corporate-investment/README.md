# SQL: Historical corporate investment analytics

**Question:** Which firms invested most, how volatile was their investment, and how did investment compare with market value?

Run `python run_sql.py` to build a SQLite database and export three query results. Demonstrates table design, GROUP BY, CTE, LAG window functions and safe division.

**Source:** [Grunfeld (1958) investment panel](https://www.statsmodels.org/stable/datasets/generated/grunfeld.html), 11 firms, 1935–1954. Historical accounting measures are **not** ESG scores or emissions data.

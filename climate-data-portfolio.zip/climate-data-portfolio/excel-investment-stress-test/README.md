# Excel: Historical firm investment scenario model

**Source:** [Grunfeld investment dataset](https://www.statsmodels.org/stable/datasets/generated/grunfeld.html). Baseline is historical 1954 firm investment; not a contemporary corporate forecast.

Workbook includes historical data, scenario assumptions and formula-driven investment sensitivity. Scenario multipliers (−20%, −10%, 0%, +10%, +20%) are **hypothetical**, not observed shocks or estimated elasticities. Change the multipliers to test alternatives. Open in Excel to recalculate formulas. This is **not** a carbon tax model because the underlying data contain no carbon emissions.

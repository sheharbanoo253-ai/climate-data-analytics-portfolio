# Environmental and Financial Data Analytics Portfolio

Five projects using **real published historical datasets**, packaged with statsmodels (no synthetic observations). The focus is reproducible methods, rather than unsupported claims about contemporary companies.

| Project | Skills | Dataset |
|---|---|---|
| [Atmospheric CO₂](python-atmospheric-co2/) | Python, pandas, NumPy | Mauna Loa atmospheric CO₂ |
| [ENSO sea-surface temperatures](r-enso-temperature/) | R, hypothesis testing | El Niño temperature data |
| [Corporate investment](sql-corporate-investment/) | SQL, CTEs, windows | Grunfeld firm panel |
| [US macroeconomic dashboard](tableau-macroeconomic-dashboard/) | Tableau, calculated fields | US quarterly macrodata |
| [Investment stress test](excel-investment-stress-test/) | Excel, formulas, scenarios | Grunfeld historical firm panel |

**Data integrity:** All CSVs are bundled from `statsmodels.datasets` and contain historical observations. Scenario multipliers in Excel are hypothetical and explicitly marked. These datasets do **not** support claims about methane facility emissions, modern ESG ratings, or real carbon-price liabilities.

## Reproduce

`pip install -r requirements.txt` then `python python-atmospheric-co2/analysis.py`, `python sql-corporate-investment/run_sql.py`. Run `Rscript r-enso-temperature/analysis.R` with R installed. Open the Excel workbook in Excel, and use the Tableau CSV to create the specified interactive dashboard in Tableau Desktop/Public.

## Data references
- Mauna Loa CO₂: Keeling and Whorf / Scripps Institution of Oceanography, as distributed in statsmodels (`statsmodels.datasets.co2`).
- El Niño: NOAA / Pacific sea-surface temperature series distributed as `statsmodels.datasets.elnino`.
- Grunfeld: Grunfeld (1958) historical investment panel, distributed as `statsmodels.datasets.grunfeld`.
- US macroeconomic data: US economic series collected by the Federal Reserve Bank of St. Louis (FRED) and distributed as `statsmodels.datasets.macrodata`.

Each subproject documents its methodology, limits, and run instructions. License of underlying third-party data must be checked separately before redistribution.
